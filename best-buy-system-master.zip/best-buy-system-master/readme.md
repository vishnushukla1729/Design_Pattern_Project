* `git pull`
* `git checkout -b branch_name_here`
* Make changes
* `git add .`  or file name in place of "."
* `git commit -m "commit message"`
* `git push`
