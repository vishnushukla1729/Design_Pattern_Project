package command;

/**
 * Created by ehaywo1 on 3/30/2017.
 */
public interface CommandInterface {
    Object execute();
}
