package decorator;

import model.Order;

/**
 * A receipt with ALL possible information
 *
 * Created by ealexhaywood on 4/30/17.
 */
public class FullDetailedReceipt implements Receipt {
    @Override
    public void printReceipt(Order order) {

    }
}
