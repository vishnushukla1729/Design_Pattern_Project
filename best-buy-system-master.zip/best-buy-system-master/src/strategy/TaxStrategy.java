package strategy;

/**
 * Created by tylerhoward on 5/12/17.
 */
public interface TaxStrategy {
    double calcSalesTax(double price);
}
